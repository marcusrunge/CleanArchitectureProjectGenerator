﻿using $rootNamespace$.Contracts;

namespace $rootNamespace$
{
    /// <summary>
    /// Defines a factory contract for creating a clean architecture module instance.
    /// </summary>
    public interface I$assemblyName$Factory
    {
        /// <summary>
        /// Creates (or returns) a assembly instance.
        /// </summary>
        I$assemblyName$ Create();
    }

    /// <summary>
    /// Default factory implementation that provides a singleton-like factory and assembly instance.
    /// </summary>
    public class $assemblyName$Factory : I$assemblyName$Factory
    {
        // Stores the singleton-like factory instance (lazy-created).
        private static I$assemblyName$Factory? _factoryInstance;

        // Stores the singleton-like instance created by this factory (lazy-created).
        private static I$assemblyName$? _assemblyInstance;

        public static I$assemblyName$Factory Instance =>
            /* What happens here:
               - Lazy initialization of the factory itself using the null-coalescing assignment operator (??=).
               - If _factoryInstance is null, a new Factory is created and cached.
               - If it is already set, the existing instance is returned.

               Notes on logic/behavior:
               - This provides a "singleton-like" access pattern without explicit locking.
               - In highly concurrent scenarios, more than one instance could be constructed transiently,
                 but the field will end up holding one of them (depending on timing). */
            _factoryInstance ??= new $assemblyName$Factory();

        /// <inheritdoc/>
        public I$assemblyName$ Create() =>
            /* What happens here:
               - Lazy initialization of the assembly instance.
               - If _assemblyInstance is null, a new Implementations.$assemblyName$ is created and cached.
               - If it is already set, the cached instance is returned.

               Purpose/intent:
               - Ensures consumers get a single shared assembly instance per process/app-domain-like context,
                 created on first demand. */
            _assemblyInstance ??= new Implementations.$assemblyName$();
    }
}