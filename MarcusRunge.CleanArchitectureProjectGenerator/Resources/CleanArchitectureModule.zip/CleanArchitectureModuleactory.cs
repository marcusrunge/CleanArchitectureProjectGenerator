﻿using $rootNamespace$.Contracts;

namespace $rootnamespace$
{
    /// <summary>
    /// Defines a factory contract for creating a clean architecture module instance.
    /// </summary>
    public interface I$safeprojectname$Factory
    {
        /// <summary>
        /// Creates (or returns) a module instance.
        /// </summary>
        I$safeprojectname$ Create();
    }

    /// <summary>
    /// Default factory implementation that provides a singleton-like factory and module instance.
    /// </summary>
    public class $safeprojectname$Factory : I$safeprojectname$Factory
    {
        // Stores the singleton-like factory instance (lazy-created).
        private static I$safeprojectname$Factory? _factoryInstance;

        // Stores the singleton-like module instance created by this factory (lazy-created).
        private static I$safeprojectname$? _moduleInstance;

        public static I$safeprojectname$Factory Instance =>
            /* What happens here:
               - Lazy initialization of the factory itself using the null-coalescing assignment operator (??=).
               - If _factoryInstance is null, a new Factory is created and cached.
               - If it is already set, the existing factory instance is returned.

               Notes on logic/behavior:
               - This provides a "singleton-like" access pattern without explicit locking.
               - In highly concurrent scenarios, more than one instance could be constructed transiently,
                 but the field will end up holding one of them (depending on timing). */
            _factoryInstance ??= new $safeprojectname$Factory();

        /// <inheritdoc/>
        public I$safeprojectname$ Create() =>
            /* What happens here:
               - Lazy initialization of the instance.
               - If _moduleInstance is null, a new Implementations.$safeprojectname$ is created and cached.
               - If it is already set, the cached module instance is returned.

               Purpose/intent:
               - Ensures consumers get a single shared module instance per process/app-domain-like context,
                 created on first demand. */
            _moduleInstance ??= new Implementations.$safeprojectname$();
    }
}