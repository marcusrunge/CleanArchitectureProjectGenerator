﻿namespace $rootnamespace$.Contracts
{

    /// <summary>
    /// Represents service B as part of the assembly contract.
    /// </summary>
    public interface IServiceB
    {
    }
}