﻿namespace $rootNamespace$.Contracts
{
    /// <summary>
    /// Defines the public contract of the assembly.
    /// </summary>
    public interface I$assemblyName$
    {
        /// <summary>
        /// Gets the IServiceA instance exposed by the assembly, if available.
        /// </summary>
        IServiceA? ServiceA { get; }

        /// <summary>
        /// Gets the IServiceB instance exposed by the assembly, if available.
        /// </summary>
        IServiceB? ServiceB { get; }
    }
}