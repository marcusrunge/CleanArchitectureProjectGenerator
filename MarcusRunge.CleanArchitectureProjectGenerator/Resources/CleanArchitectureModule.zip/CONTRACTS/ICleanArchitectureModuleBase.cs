﻿namespace $rootnamespace$.Contracts
{
    /// <summary>
    /// Internal base contract for exposing services to internal consumers.
    /// </summary>
    internal interface I$safeprojectname$Base
    {
        /// <summary>
        /// Gets the IServiceI instance used for internal assembly operations.
        /// </summary>
        IServiceI? ServiceI { get; }
    }
}