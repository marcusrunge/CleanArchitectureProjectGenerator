﻿namespace $rootNamespace$.Contracts
{
    /// <summary>
    /// Internal base contract for exposing services to internal consumers.
    /// </summary>
    internal interface I$assemblyName$Base
    {
        /// <summary>
        /// Gets the IServiceI instance used for internal assembly operations.
        /// </summary>
        IServiceI? ServiceI { get; }
    }
}