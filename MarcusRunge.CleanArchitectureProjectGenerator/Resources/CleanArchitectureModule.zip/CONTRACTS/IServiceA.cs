﻿namespace $rootNamespace$.Contracts
{

    /// <summary>
    /// Represents service A as part of the assembly contract.
    /// </summary>
    public interface IServiceA
    {
    }
}