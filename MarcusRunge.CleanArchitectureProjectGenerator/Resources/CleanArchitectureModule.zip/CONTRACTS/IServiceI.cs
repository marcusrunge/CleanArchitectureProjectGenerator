﻿namespace $rootNamespace$.Contracts
{
    /// <summary>
    /// Internal contract that identifies IServiceI within the assembly.
    /// </summary>
    internal interface IServiceI
    {
    }
}