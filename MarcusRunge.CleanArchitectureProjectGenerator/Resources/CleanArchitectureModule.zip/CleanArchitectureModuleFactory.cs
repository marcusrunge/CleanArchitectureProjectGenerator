﻿using $basenamespace$.Contracts;
using Microsoft.Extensions.Logging;

namespace $basenamespace$
{
    /// <summary>
    /// Defines a factory contract for creating a clean architecture module instance.
    /// </summary>
    public interface I$shortprojectname$Factory
    {
        /// <summary>
        /// Creates (or returns) a module instance.
        /// </summary>
        I$shortprojectname$ Create();
    }

    /// <summary>
    /// Default factory implementation that provides a singleton-like factory and module instance.
    /// </summary>
    public class $shortprojectname$Factory : I$shortprojectname$Factory
    {        
        // Stores the singleton-like module instance created by this factory (lazy-created).
        private static I$shortprojectname$? _moduleInstance;

        // Logger reference for potential logging; can be null if not provided.
        private readonly ILogger? _logger;

        public $shortprojectname$Factory()
        {
        }

        public $shortprojectname$Factory(ILogger? logger)
        {
            _logger = logger;
        }


        /// <inheritdoc/>
        public I$shortprojectname$ Create() =>
            /* What happens here:
               - Lazy initialization of the instance.
               - If _moduleInstance is null, a new Implementations.$safeprojectname$ is created and cached.
               - If it is already set, the cached module instance is returned.

               Purpose/intent:
               - Ensures consumers get a single shared module instance per process/app-domain-like context,
                 created on first demand. */
            _moduleInstance ??= new Implementations.$shortprojectname$(_logger);
    }
}