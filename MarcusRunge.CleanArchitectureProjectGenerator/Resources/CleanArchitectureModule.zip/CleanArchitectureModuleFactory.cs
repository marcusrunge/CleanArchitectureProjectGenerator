﻿using $rootnamespace$.Contracts;
using Microsoft.Extensions.Logging;

namespace $rootnamespace$
{
    /// <summary>
    /// Defines a factory contract for creating a clean architecture module instance.
    /// </summary>
    public interface I$safeprojectname$Factory
    {
        /// <summary>
        /// Creates (or returns) a module instance.
        /// </summary>
        I$safeprojectname$ Create();
    }

    /// <summary>
    /// Default factory implementation that provides a singleton-like factory and module instance.
    /// </summary>
    public class $safeprojectname$Factory : I$safeprojectname$Factory
    {
        // Stores the singleton-like factory instance (lazy-created).
        private static I$safeprojectname$Factory? _factoryInstance;

        // Stores the singleton-like module instance created by this factory (lazy-created).
        private static I$safeprojectname$? _moduleInstance;

        // Logger reference for potential logging; can be null if not provided.
        private readonly ILogger? _logger;

        public $safeprojectname$Factory()
        {
        }

        public $safeprojectname$Factory(ILogger? logger)
        {
            _logger = logger;
        }


        /// <inheritdoc/>
        public I$safeprojectname$ Create() =>
            /* What happens here:
               - Lazy initialization of the instance.
               - If _moduleInstance is null, a new Implementations.$safeprojectname$ is created and cached.
               - If it is already set, the cached module instance is returned.

               Purpose/intent:
               - Ensures consumers get a single shared module instance per process/app-domain-like context,
                 created on first demand. */
            _moduleInstance ??= new Implementations.$safeprojectname$(_logger);
    }
}